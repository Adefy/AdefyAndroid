AJS.createRectangleActor(360, 640, 720, 1280)
.setTexture("pudding")
.setLayer(0);

// Loading bar
var loading = AJS.createRectangleActor(0, 0, 10, 15)
.setColor(new AJSColor3(0, 0, 255))
.setLayer(8)
.resize(300, null, 10, null, 1900, 800);

setTimeout(function(){ loading.resize(600, null, 300, null, 1200); }, 2800);
setTimeout(function(){ loading.resize(1000, null, 300, null, 1700); }, 4100);
setTimeout(function(){ loading.resize(1480, null, 500, null, 2400); }, 5900);

// Spinner
AJS.createSquareActor(672, 70, 64)
.setTexture("spinner").setLayer(8)
.rotate(2000, 8000);

// Force a finish for the tech demo
setTimeout(function() {
  window.AdefyGLI.Engine().triggerEnd();
}, 8000);

// Price
AJS.createRectangleActor(600, 1000, 256, 128)
.setTexture("price")
.move(300, 800, 8000);