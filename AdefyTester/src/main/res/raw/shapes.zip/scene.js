window.AdefyGLI.Engine().setOrientation("landscape");

// Loading bar
var loading = AJS.createRectangleActor(0, 0, 10, 15)
.setColor(new AJSColor3(0, 0, 255))
.setLayer(8)
.resize(300, null, 10, null, 1900, 800);

setTimeout(function(){ loading.resize(600, null, 300, null, 1200); }, 2800);
setTimeout(function(){ loading.resize(1000, null, 300, null, 1700); }, 4100);
setTimeout(function(){ loading.resize(1480, null, 500, null, 2400); }, 5900);

// Spinner
AJS.createSquareActor(672, 70, 64)
.setTexture("spinner").setLayer(8)
.rotate(2000, 8000);

// Force a finish for the tech demo
setTimeout(function() {
  window.AdefyGLI.Engine().triggerEnd();
}, 12100);

// Shape demo
AJS.setClearColor(23, 6, 56);

// Setup shapes!
var circle, triangle, square, circle2, triangle2, square2;
var circle3, circle4, circle5, circle6;

spawnInitial();   // Spawn first three shapes
firstMotion();    // Split, then left

// Spawn and move second set of shapes
setTimeout(function(){ spawnSecondSet(); }, 3000);

// Transition!
setTimeout(function(){ transition(); }, 5400);

// Beziers
setTimeout(function(){ bezierDemo(); }, 6200);

// Drop shapes
setTimeout(function(){ dropShapes(); }, 8500);

// Final rain effect!
setTimeout(function(){ makeItRain(); }, 11100);

// Scene animations
function spawnInitial() {

  // Polygon animations are broken, fake it by hiding the circle, and
  // fading it in (not really faking it, but it's something)
  circle = AJS.createCircleActor(640, 360, 75, 23, 6, 56);

  // Setup square and triangle normally
  square = AJS.createSquareActor(640, 360, 40, 255, 189, 0);
  triangle = AJS.createTriangleActor(640, 360, 40, 40, 255, 0, 0);

  // Expand gracefully
  square.resize(150, 150, 40, 40, 500);
  triangle.resize(150, 150, 40, 40, 500);

  // Fade in our circle
  circle.colorTo(0, 255, 255, 300, 200);
}

function firstMotion() {

  // Queue second batch of animations, first motion
  triangle.move(225, null, 400, 1200);
  square.move(1055, null, 400, 1200);

  // Queue third batch, move shapes to the left
  triangle.move(null, 570, 800, 2000);
  circle.move(225, null, 800, 2000);
  square.move(225, 150, 800, 2000);
}

function spawnSecondSet() {

  // Spawn 2nd set of shapes
  triangle2 = AJS.createTriangleActor(475, 570, 150, 150, 255, 0, 0);
  circle2 = AJS.createCircleActor(475, 360, 75, 0, 255, 255);
  square2 = AJS.createSquareActor(475, 150, 150, 255, 189, 0);

  // Tilt
  triangle2.rotate(10, 100, 100);
  circle2.rotate(10, 100, 100);
  square2.rotate(10, 100, 100);

  // Move right
  triangle2.move(1055, null, 800, 100);
  circle2.move(1055, null, 800, 100);
  square2.move(1055, null, 800, 100);

  // Inertia
  triangle2.rotate(-3, 150, 900);
  circle2.rotate(-3, 150, 900);
  square2.rotate(-3, 150, 900);

  triangle2.rotate(0, 100, 1050);
  circle2.rotate(0, 100, 1050);
  square2.rotate(0, 100, 1050);

  // Tilt for another move
  triangle2.rotate(-10, 100, 1350);
  circle2.rotate(-10, 100, 1350);
  square2.rotate(-10, 100, 1350);

  // Move left
  triangle2.move(475, null, 800, 1350);
  circle2.move(475, null, 800, 1350);
  square2.move(475, null, 800, 1350);

  // Inertia
  triangle2.rotate(3, 150, 2150);
  circle2.rotate(3, 150, 2150);
  square2.rotate(3, 150, 2150);

  triangle2.rotate(0, 100, 2300);
  circle2.rotate(0, 100, 2300);
  square2.rotate(0, 100, 2300);
}

function transition() {

  // Hide three new shapes, and top + bottom initial ones
  square.resize(20, 20, 150, 150, 300);
  triangle.resize(20, 20, 150, 150, 300);
  square2.resize(20, 20, 150, 150, 300);
  triangle2.resize(20, 20, 150, 150, 300);

  square.colorTo(23, 6, 56, 200, 200);
  triangle.colorTo(23, 6, 56, 200, 200);
  square2.colorTo(23, 6, 56, 200, 200);
  triangle2.colorTo(23, 6, 56, 200, 200);

  setTimeout(function() {

    // Destroy faded actors
    square.destroy();
    triangle.destroy();
    square2.destroy();
    triangle2.destroy();

    // Spawn circles!
    //
    // Left batch
    circle5 = AJS.createCircleActor(225, 570, 75, 23, 6, 56);
    circle6 = AJS.createCircleActor(225, 150, 75, 23, 6, 56);

    // Right batch
    circle3 = AJS.createCircleActor(475, 570, 75, 23, 6, 56);
    circle4 = AJS.createCircleActor(475, 150, 75, 23, 6, 56);

    // Fade them in
    circle3.colorTo(0, 255, 255, 200, 200);
    circle4.colorTo(0, 255, 255, 200, 200);
    circle5.colorTo(0, 255, 255, 200, 200);
    circle6.colorTo(0, 255, 255, 200, 200);

  }, 400);
}

function bezierDemo() {

  cp1 = [{ x: 200, y: 600 }];
  cp2 = [{ x: 200, y: 400 }];

  // Move right, with control points
  circle2.move(1055, null, 800, 0);
  circle3.move(1055, null, 900, 0, cp1);
  circle4.move(1055, null, 1000, 0, cp2);

  circle2.colorTo(195, 90, 90, 600, 300);
  circle3.colorTo(137, 195, 90, 600, 300);
  circle4.colorTo(104, 90, 195, 600, 300);

  // Move back left, same control points
  circle2.move(475, null, 800, 1200);
  circle3.move(475, null, 900, 1200, cp1);
  circle4.move(475, null, 1000, 1200, cp2);
}

function dropShapes() {

  setTimeout(function() { circle3.enablePsyx(1, 0.2, 0.8); }, 100);
  setTimeout(function() { circle2.enablePsyx(10, 0.2, 0.8); }, 300);
  setTimeout(function() { circle4.enablePsyx(100, 0.2, 0.8); }, 500);

  setTimeout(function() { circle5.enablePsyx(1, 0.2, 0.9); }, 800);
  setTimeout(function() { circle.enablePsyx(10, 0.2, 0.9); }, 1000);
  setTimeout(function() { circle6.enablePsyx(100, 0.2, 0.9); }, 1200);

  setTimeout(function() {

    circle3.destroy();
    circle2.destroy();
    circle4.destroy();
    circle5.destroy();
    circle.destroy();
    circle6.destroy();

  }, 2600);
}

function makeItRain() {

  // Spawn floor
  AJS.createRectangleActor(640, 100, 640, 64, 23, 6, 56).enablePsyx(0, 0.8, 0.6);

  var time = 0;

  // Rain!
  for(var y = 0; y < 16; y++) {
    for(var x = 0; x < 8; x++) {

      time += 50;

      setTimeout(function() {

        var px = Math.floor(Math.random() * 1280);
        var py = Math.floor(Math.random() * 720) + 720;

        var r = Math.floor(Math.random() * 255);
        var g = Math.floor(Math.random() * 255);
        var b = Math.floor(Math.random() * 255);

        var radius = Math.floor(Math.random() * 40) + 10;

        AJS.createCircleActor(px, py, radius, r, g, b)
        .enablePsyx(Math.random() * 100, 0.5, 0.5);

      }, time);
    }
  }
}