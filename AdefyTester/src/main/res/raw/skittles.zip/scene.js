var skittles, guider, anger, taste, red, blue, black, yellow;

AJS.setClearColor(173, 216, 230);

guiderColor = new AJSColor3(255, 216, 230);

// Create walls to keep skittles in
AJS.createRectangleActor(0, 810, 10, 1280).setLayer(0)
.enablePsyx(0, 0.5, 0.5);

AJS.createRectangleActor(720, 810, 10, 1180).setLayer(0)
.enablePsyx(0, 0.5, 0.5);

AJS.createRectangleActor(360, 1280, 700, 10).setLayer(0)
.enablePsyx(0, 0.5, 0.5);

// Set background
AJS.createRectangleActor(361, 640, 1280, 720)
.setRotation(-90).setTexture("bg").setLayer(1);

// Guiding bar so the skittles drop at an angle
guider = AJS.createRectangleActor(215, 1000, 500, 10)
.setRotation(102).setColor(guiderColor).setLayer(0)
.enablePsyx(0, 0.5, 0.8);

// Metal and stone decorations

// Left Side
AJS.createRectangleActor(15, 55, 72, 48)
.setTexture("stone").setRotation(0)
.enablePsyx(0, 0, 1).setLayer(2);
AJS.createRectangleActor(20, 118, 100, 48)
.setTexture("stone").setRotation(90)
.enablePsyx(0, 0, 1).setLayer(2);

//Right Side
AJS.createRectangleActor(700, 58, 64, 64)
.setTexture("metal").setRotation(90).setLayer(2)
.enablePsyx(0, 0, 1);
AJS.createRectangleActor(640, 58, 64, 64)
.setTexture("metal").setRotation(0).setLayer(2)
.enablePsyx(0, 0, 1);
AJS.createRectangleActor(680, 105, 120, 48)
.setTexture("stone").setRotation(0).setLayer(2)
.enablePsyx(0, 0, 1);
AJS.createRectangleActor(710, 168, 100, 48)
.setTexture("stone").setRotation(90).setLayer(2)
.enablePsyx(0, 0, 1);
AJS.createRectangleActor(667, 150, 64, 64)
.setTexture("metal").setRotation(0).setLayer(2)
.enablePsyx(0, 0, 1);

// Skittles package
skittles = AJS.createRectangleActor(-100, 1500, 264, 567)
.setRotation(90).setTexture("skittles").setLayer(5);

skittles.move(205, 1240, 800, 0)
skittles.rotate(35, 800, 0)

// Ground
AJS.createRectangleActor(360, 10, 720, 50)
.setTexture("ground").setLayer(3)
.enablePsyx(0, 0.3, 0.8);

// Loading bar
var loading = AJS.createRectangleActor(0, 0, 10, 15)
.setColor(new AJSColor3(255, 0, 0))
.setLayer(8)
.resize(300, null, 10, null, 1900, 800);

setTimeout(function(){ loading.resize(600, null, 300, null, 1200); }, 2800);
setTimeout(function(){ loading.resize(1000, null, 300, null, 1700); }, 4100);
setTimeout(function(){ loading.resize(1480, null, 500, null, 2400); }, 5900);

// Spinner
AJS.createSquareActor(672, 70, 64)
.setTexture("spinner").setLayer(8)
.rotate(2000, 8000);

// Force a finish for the tech demo
setTimeout(function() {
  window.AdefyGLI.Engine().triggerEnd();
}, 8000);

// Create Angry Birds
angryBirds();

// Drop the skittles
setTimeout(function() {
  makeItSkittle();
}, 805);

// Empty the bag animation
setTimeout(function() {
  skittles.setLayer(3);
  emptyBag();
  guider.disablePsyx();
}, 4000);

// Show the rainbow and tagline
setTimeout(function() {
  makeItRainbow();
}, 5080);

// Rotate the skittles bag when it's empty
function emptyBag()  {
  skittles.rotate(-90, 1000, 0);
  skittles.move(360, 900, 1000, 0);
}

function angryBirds() {

  // Render the birds (and pig) on the ground
  yellow = AJS.createRectangleActor(100, 64, 64, 64)
  .setRotation(273).setTexture("angry_yellow").setLayer(2);
  blue = AJS.createRectangleActor(210, 64, 64, 64)
  .setRotation(273).setTexture("angry_blue").setLayer(2);

  AJS.createCircleActor(320, 64, 40)
  .setLayer(2).enablePsyx(0, 0, 2.0)
  .attachTexture("pig", 32, 32, 0, 0, 180);

  red = AJS.createRectangleActor(430, 64, 64, 64)
  .setRotation(273).setTexture("angry_red").setLayer(2);
  black = AJS.createRectangleActor(540, 64, 64, 64)
  .setRotation(273).setTexture("angry_black").setLayer(2);

  // Timeout their first jump so it syncs with skittles drop
  setTimeout(function() {
    yellow.disablePsyx();
    yellow.move(null, Math.floor(Math.random() * 20 ) + 200, 400, 0);

    blue.disablePsyx();
    blue.move(null, Math.floor(Math.random() * 20 ) + 200, 400, 0);

    red.disablePsyx();
    red.move(null, Math.floor(Math.random() * 20 ) + 200, 400, 0);

    black.disablePsyx();
    black.move(null, Math.floor(Math.random() * 20 ) + 200, 400, 0);

  }, 1000)

  // Start the bounce after they've peaked first jump
  setTimeout(function() {
    yellow.enablePsyx(100000, 0, 1);
    blue.enablePsyx(100000, 0, 1);
    red.enablePsyx(100000, 0, 1);
    black.enablePsyx(100000, 0, 1);
  }, 1500)
}

// Show the rainbow and the tagline
function makeItRainbow()  {

  // Set the 2 rainbows behind the package
  rainbow2 = AJS.createRectangleActor(365, 900, 172, 512)
  .setTexture("rainbow2").setRotation(-90).setLayer(2);
  rainbow = AJS.createRectangleActor(365, 900, 172, 512)
  .setTexture("rainbow").setRotation(-90).setLayer(2);


  //move the rainbows
  rainbow.move(null, 1098, 500, 0);

  setTimeout(function(){
    rainbow2.move(null, 700, 500, 0);
  }, 1005)

  // Delay the text so the rainbows are in place
  setTimeout(function(){
    anger = AJS.createRectangleActor(360, 1200, 128, 512)
                .setTexture("anger").setRotation(-90).setLayer(5);
  }, 505);

  setTimeout(function() {
    var taste = AJS.createRectangleActor(360, 600, 64, 512)
                .setTexture("taste").setRotation(-90).setLayer(5);
  }, 1505);

}

// Make the skittles drop from the package
function makeItSkittle()  {
  var time = 0, rotation;

  function scheduleSkittleDrop(time) {

    setTimeout(function() {

      var skittleColour = Math.floor(Math.random() * 5);

      var px = Math.floor(Math.random() * 50) + 200;
      var py = Math.floor(Math.random() * 150) + 1100;

      var skittle = AJS.createCircleActor(px, py, 5);
      skittle.setLayer(4).enablePsyx(1, 0.5, 0.6);

      // Rotate skittle bag every 8 skittles
      rotation = Math.floor(Math.random() * 6) + 30;
      if(time % 88 == 0) { skittles.rotate(rotation, 88); }

      // Choose Skittle color randomly out of the 5 and also
      // apply a random rotation between 30 and 35 to the bag
      if(skittleColour == 0)  {
        skittle.attachTexture("red", 12, 12);
      } else if(skittleColour == 1)  {
        skittle.attachTexture("orange", 12, 12);
      } else if(skittleColour == 2)  {
        skittle.attachTexture("purple", 12, 12);
      } else if(skittleColour == 3)  {
       skittle.attachTexture("green", 12, 12);
      } else if(skittleColour == 4)  {
        skittle.attachTexture("yellow", 12, 12);
      }

    }, time);
  }

  // Skittles!
  for(var y = 0; y < 8; y++) {
    for(var x = 0; x < 6; x++) {

      time += 22;

      scheduleSkittleDrop(time);
    }
  }
}